let valor = document.querySelector("#valor");
let btVerificar = document.querySelector("#brVerificar");
let h3Resultado = document.querySelector("#h3Resultado");


function verificarImparOuPar(){
    let vlr = Number(valor.value);

    if (vlr % 2 === 0) {
        h3Resultado.textContent = "O número é par.";
    } else {
        h3Resultado.textContent = "O número é ímpar.";
    }
}

btVerificar.onclick = function() {
    verificarImparOuPar();
};
