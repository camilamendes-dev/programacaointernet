let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let btVerificar = document.querySelector("#btVerificar");
let h3Resultado = document.querySelector("#h3Resultado");

function retornarMaiorValor(){
    let vlr1 = Number(valor1.value);
    let vlr2 = Number(valor2.value);

    if(vlr1 > vlr2){
        h3Resultado.textContent = "O " + vlr1 + " é maior."
    }else if(vlr1 < vlr2){
        h3Resultado.textContent = "O " + vlr2 + " é maior."
    }else{
        h3Resultado.textContent = "Os valores são iguais."
    }

}


btVerificar.onclick = function(){
    retornarMaiorValor();
}