let inputDolar = document.querySelector("#inputDolar");
let btCalcularReajuste = document.querySelector("#btCalcularReajuste");

let resultadoA = document.querySelector("#resultadoA");
let resultadoB = document.querySelector("#resultadoB");
let resultadoC = document.querySelector("#resultadoC");
let resultadoD = document.querySelector("#resultadoD");

function CalcularReajuste() {
    let valor = Number(inputDolar.value);

    // Usando a fórmula valor + (valor * (x / 100))
    let reajuste1 = valor + (valor * (1 / 100));
    let reajuste2 = valor + (valor * (2 / 100));
    let reajuste5 = valor + (valor * (5 / 100));
    let reajuste10 = valor + (valor * (10 / 100));

    resultadoA.textContent = "a) Reajuste de 1%: " + reajuste1;
    resultadoB.textContent = "b) Reajuste de 2%: " + reajuste2;
    resultadoC.textContent = "c) Reajuste de 5%: " + reajuste5;
    resultadoD.textContent = "d) Reajuste de 10%: " + reajuste10;
}

btCalcularReajuste.onclick = CalcularReajuste;