let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let h3Resultado = document.querySelector("#h3Resultado");
let btResultados = document.querySelector("#btResultados");

let campoSoma = document.querySelector("#resultadoSoma");
let campoSubtracao = document.querySelector("#resultadoSubtracao");
let campoMultiplicacao = document.querySelector("#resultadoMultiplicacao");
let campoDivisao = document.querySelector("#resultadoDivisao");

function RetonarResultados() {
    let vlr1 = Number(valor1.value);
    let vlr2 = Number(valor2.value);

    let resultadoSoma = vlr1 + vlr2;
    let resultadoSubtracao = vlr1 - vlr2;
    let resultadoMultiplicacao = vlr1 * vlr2;
    let resultadoDivisao = vlr2 !== 0 ? (vlr1 / vlr2) : "Divisão por zero!";

    campoSoma.textContent = 'a) Soma: ' + resultadoSoma;
    campoSubtracao.textContent = 'b) Subtração: ' + resultadoSubtracao;
    campoMultiplicacao.textContent = 'c) Multiplicação: ' + resultadoMultiplicacao;
    campoDivisao.textContent = 'd) Divisão: ' + resultadoDivisao;
}

btResultados.onclick = RetonarResultados;