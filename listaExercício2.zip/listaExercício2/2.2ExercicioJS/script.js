let inputQuantasPessoas = document.querySelector("#inputQuantasPessoas");
let btCalcular = document.querySelector("#btCalcular");

let resultadoOvo = document.querySelector("#resultadoOvo");
let resultadoQueijo = document.querySelector("#resultadoQueijo");

function Calcular() {
    let pessoas = Number(inputQuantasPessoas.value);

    let quantidadeOvos = pessoas * 2;
    let quantidadeQueijo = pessoas * 50; // gramas

    resultadoOvo.textContent = "a) Quantidade de ovos: " + quantidadeOvos;
    resultadoQueijo.textContent = "b) Quantidade de queijo: " + quantidadeQueijo + " gramas";
}

btCalcular.onclick = Calcular;
