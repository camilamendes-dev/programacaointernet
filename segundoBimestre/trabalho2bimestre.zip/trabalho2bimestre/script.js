//atividade 1
let x = document.querySelector("#x");
let y = document.querySelector("#y");
let z = document.querySelector("#z");
let h3Resultado = document.querySelector("#h3Resultado");
let btResultado = document.querySelector("#btResultado");

function calcularTriangulo(){

    let valorX = Number(x.value);
    let valorY = Number(y.value);
    let valorZ = Number(z.value);

    if ((valorX < (valorY + valorZ)) && (valorY < (valorX + valorZ)) && (valorZ < (valorX + valorY))) {
        if (valorX === valorY && valorY === valorZ) {
            h3Resultado.innerHTML = "É um triângulo equilátero.";
        } else if (valorX === valorY || valorX === valorZ || valorY === valorZ) {
            h3Resultado.innerHTML = "É um triângulo isósceles.";
        } else {
            h3Resultado.innerHTML = "É um triângulo escaleno.";
        }
    } else {
        h3Resultado.innerHTML = "Os valores fornecidos não formam um triângulo.";
    }
}

btResultado.onclick = calcularTriangulo;


//atividade 2
let peso = document.querySelector("#peso");
let altura = document.querySelector("#altura");
let h3IMC = document.querySelector("#h3IMC");
let pTabela = document.querySelector("#pTabela");
let btCalcular = document.querySelector("#btCalcular");

function calcularIMC() {
    let pesoKG = Number(peso.value);
    let alturaM = Number(altura.value);
    let valorIMC = pesoKG / (alturaM * alturaM);
    let classificacao = "";

    if (valorIMC < 18.5) {
        classificacao = "Abaixo do peso";
    } else if (valorIMC < 25) {
        classificacao = "Peso normal";
    } else if (valorIMC < 30) {
        classificacao = "Sobrepeso";
    } else if (valorIMC < 35) {
        classificacao = "Obesidade grau 1";
    } else if (valorIMC < 40) {
        classificacao = "Obesidade grau 2";
    } else {
        classificacao = "Obesidade grau 3";
    }

    h3IMC.innerHTML = "Seu IMC é: " + valorIMC.toFixed(2) + "<br>Classificação: " + classificacao;

    pTabela.innerHTML = 
        "<b>Classificações gerais:</b><br>" +
        "Abaixo de 18.5 → Abaixo do peso<br>" +
        "18.5 a 24.9 → Peso normal<br>" +
        "25 a 29.9 → Sobrepeso<br>" +
        "30 a 34.9 → Obesidade grau 1<br>" +
        "35 a 39.9 → Obesidade grau 2<br>" +
        "40 ou mais → Obesidade grau 3";
}

btCalcular.onclick = calcularIMC;


//atividade 3
let ano = document.querySelector("#ano");
let valor = document.querySelector("#valor");
let h3Imposto = document.querySelector("#h3Imposto");
let btImposto = document.querySelector("#btImposto");

function calcularImposto() {
    let anos = Number(ano.value);
    let valorFipe = Number(valor.value);
    let imposto = 0;

    if (anos < 1990) {
        imposto = valorFipe * 0.01;
        h3Imposto.innerHTML = "Imposto a ser pago: R$ " + imposto.toFixed(2);
    } else if (anos >= 1990) {
        imposto = valorFipe * 0.015;
        h3Imposto.innerHTML = "Imposto a ser pago: R$ " + imposto.toFixed(2);
    } else {
        h3Imposto.innerHTML = "Os dados inseridos estão incorretos.";
    }
}

btImposto.onclick = calcularImposto;


//atividade 4
let cargo = document.querySelector("#cargo");
let salario = document.querySelector("#salario");
let h3Salario = document.querySelector("#h3Salario");
let btSalario = document.querySelector("#btSalario");



function calcularAumento() {
    let cargoAtual = Number(cargo.value);
    let salarioAtual = Number(salario.value);
    let percentual;
    let nomeCargo;

    if (cargoAtual === 101) {
        percentual = 10;
        nomeCargo = "Gerente";
    } else if (cargoAtual === 102) {
        percentual = 20;
        nomeCargo = "Engenheiro";
    } else if (cargoAtual === 103) {
        percentual = 30;
        nomeCargo = "Técnico";
    } else {
        percentual = 40;
        nomeCargo = "Outro cargo";
    }

    let aumento = salarioAtual * (percentual / 100);
    let novoSalario = salarioAtual + aumento;

    h3Salario.innerHTML = 
        "Cargo: " + nomeCargo + " (Código: " + cargoAtual + ")<br>" +
        "Salário antigo: R$ " + salarioAtual.toFixed(2) + "<br>" +
        "Percentual de aumento: " + percentual + "%<br>" +
        "Aumento: R$ " + aumento.toFixed(2) + "<br>" +
        "Novo salário: R$ " + novoSalario.toFixed(2);
}

btSalario.onclick = calcularAumento;


//atividade 5

let saldo = document.querySelector("#saldo");
let btCalcularCredito = document.querySelector("#btCalcularCredito");
let h3Credito = document.querySelector("#h3Credito");

function calcularCredito(){
    let saldoMedio = Number(saldo.value);
    let percentualCredito;

    
            if (saldoMedio <= 200) {
                percentualCredito = 0;
            } else if (saldoMedio <= 400) {
                percentualCredito = 20;
            } else if (saldoMedio <= 600) {
                percentualCredito = 30;
            } else {
                percentualCredito = 40;
            }

    let creditoBancario = saldoMedio * (percentualCredito / 100);

     h3Credito.innerHTML =
                "Seu saldo médio no banco é de " + saldoMedio +
                " e o valor de crédito liberado é de R$" + creditoBancario.toFixed(2) + ".";
}

btCalcularCredito.onclick = calcularCredito;


//atividade 6
let codigo = document.querySelector("#codigo");
let quantidadeItem = document.querySelector("#quantidadeItem");
let btCalcularPedido = document.querySelector("#btCalcularPedido");
let h3Pedido = document.querySelector("#h3Pedido");

function calcularPedido(){
    let codigoProduto = Number(codigo.value);
    let quantidadeProduto = Number(quantidadeItem.value);

    let nomeItem = "";
    let preco = 0;

    if (codigoProduto === 1){
        nomeItem = "Cachorro quente";
        preco = 11.00;
    }else if (codigoProduto === 2){
        nomeItem = "Bauru";
        preco = 8.50
    }else if (codigoProduto === 3){
        nomeItem = "Misto quente";
        preco = 8.00;
    }else if (codigoProduto === 4){
        nomeItem = "Hamburguer";
        preco = 9.00;
    }else if (codigoProduto === 5){
        nomeItem = "Cheeseburguer"; 
        preco = 10.00;
    } else if (codigoProduto === 6){
        nomeItem = "Refrigerante";
        preco = 4.50;
    } else{
        h3Pedido.innerHTML = "Código inválido. Insira um número de 1 a 6.";
        return;
        }

   
    let valorPedido = quantidadeProduto * preco;

    h3Pedido.innerHTML =
                "Item: " + nomeItem + "<br>" +
                "Quantidade: " + quantidadeProduto + "<br>" +
                "Valor total: R$ " + valorPedido.toFixed(2);
    }

btCalcularPedido.onclick = calcularPedido;

//atividade 7
let valorProduto = document.querySelector("#valorProduto");
let formaPagamento = document.querySelector("#formaPagamento");
let btCalcularValor = document.querySelector("#btCalcularValor");
let h3SistemaVendas = document.querySelector("#h3SistemaVendas");

function sistemaVendas() {
    let valorEtiqueta = Number(valorProduto.value);
    let condicaoPagamento = Number(formaPagamento.value);

    let valorFinal;

    if (condicaoPagamento === 1) {
        valorFinal = valorEtiqueta - (valorEtiqueta * 0.10);
    } else if (condicaoPagamento === 2) {
        valorFinal = valorEtiqueta - (valorEtiqueta * 0.15);
    } else if (condicaoPagamento === 3) {
        valorFinal = valorEtiqueta;
    } else if (condicaoPagamento === 4) {
        valorFinal = valorEtiqueta + (valorEtiqueta * 0.10);
    } else {
        h3SistemaVendas.innerHTML = "Código inválido. Insira um código entre 1 e 4.";
        return;
    }

    h3SistemaVendas.innerHTML =
        "Conforme a condição de pagamento escolhida, o valor final do pedido é de: R$ " +
        valorFinal.toFixed(2) + ".";
}

btCalcularValor.onclick = sistemaVendas;


//atividade 8
let nivelProfessor = document.querySelector("#nivelProfessor");
let qtdeAulas = document.querySelector("#qtdeAulas");
let btCalcularPagamento = document.querySelector("#btCalcularPagamento");
let h3ValorPagamento = document.querySelector("#h3ValorPagamento");

function sistemaDePagamentos(){
    let professorNivel = Number(nivelProfessor.value);
    let horasAulas = Number(qtdeAulas.value);
    let valorHora;


    if (professorNivel === 1){
        valorHora = 12.00;
    } else if (professorNivel === 2){
        valorHora = 17.00;
    } else if (professorNivel === 3){
        valorHora = 25.00;
    } else{
        h3ValorPagamento.innerHTML = "Nível inválido. Insira um nível de professor entre 1 e 3.";
        return;
    }

    let salarioProfessor = valorHora * horasAulas * 4.5;

    h3ValorPagamento.innerHTML = "O valor do salário desse professor é de: R$ " + salarioProfessor.toFixed(2) + ".";
}

btCalcularPagamento.onclick = sistemaDePagamentos;