let diaHoje = document.querySelector("#diaHoje");
let mesHoje = document.querySelector("#mesHoje");
let btCalcular = document.querySelector("#btCalcular");
let h3ContagemDias = document.querySelector("#h3ContagemDias");

function contarDias(){
    let dia = Number(diaHoje.value);
    let mes = Number(mesHoje.value);


    // Total de dias = dias dos meses anteriores + dia atual. -1 pq o mês atual ainda não fechou 30 dias.
    let totalDias = (mes - 1) * 30 + dia;

    h3ContagemDias.textContent = "Já se passaram " + totalDias + " dias desde o começo do ano.";
}

btCalcular.onclick = contarDias;