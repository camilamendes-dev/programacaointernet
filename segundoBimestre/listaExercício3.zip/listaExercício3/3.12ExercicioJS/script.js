let numero = document.querySelector("#numero");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function separarDigitos() {
    let valor = Number(numero.value);


    // dividir por 100. para descobrir se tem centena ou não.
    //a função parseInt usamos para descartar os decimais, imprimindo nº inteiro.
    let centena = parseInt(valor / 100);

    //valor % 100 // O operador % é o módulo (ou resto da divisão). já tirando a centena. (ou seja, sobra dezena e unidade)
    let dezena = parseInt((valor % 100) / 10);


    let unidade = valor % 10;

    h3Resultado.innerHTML = 
    "Centena = " + centena + "<br>" +
    "Dezena = " + dezena + "<br>" +
    "Unidade = " + unidade;

}

btCalcular.onclick = separarDigitos;
