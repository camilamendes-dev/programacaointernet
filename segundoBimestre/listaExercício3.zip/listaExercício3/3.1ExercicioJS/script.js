let largura = document.querySelector("#largura");
let comprimento = document.querySelector("#comprimento");
let btCalcularArea = document.querySelector("#btCalcularArea");
let resultadoTerreno = document.querySelector("#resultadoTerreno");

function calcularArea() {
    let larguraValor = Number(largura.value);
    let comprimentoValor = Number(comprimento.value);

    let area = larguraValor * comprimentoValor;

    resultadoTerreno.textContent = "A área do terreno é de " + area + " m²";
}

btCalcularArea.onclick = calcularArea;