let precoLitro = document.querySelector("#precoLitro");
let pagamento = document.querySelector("#pagamento");
let btCalcular = document.querySelector("#btCalcular");
let h3QtdeLitros = document.querySelector("#h3QtdeLitros");

function calcularLitros(){
    let vlrLitro = Number(precoLitro.value);
    let vlrPagamento = Number(pagamento.value);

    let QtdeLitros = vlrPagamento / vlrLitro;

    h3QtdeLitros.textContent = "Você conseguiu abastecer o total de " +QtdeLitros+ " litros em seu tanque.";


}


btCalcular.onclick = function(){
    calcularLitros();
}