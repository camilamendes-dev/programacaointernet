let raio = document.querySelector("#raio");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularAreaPizza() {
    let r = Number(raio.value);
    let pi = 3.14;

    // como é ao quadrado, o r aparece multiplcando 2x
    let area = pi * r * r;

    h3Resultado.textContent = "A área da pizza é: " + area.toFixed(2) + " cm²";
}

btCalcular.onclick = calcularAreaPizza;
