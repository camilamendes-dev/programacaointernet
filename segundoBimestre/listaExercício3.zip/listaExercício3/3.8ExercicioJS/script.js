let camisetasP = document.querySelector("#camisetasP");
let camisetasM = document.querySelector("#camisetasM");
let camisetasG = document.querySelector("#camisetasG");
let btCalcular = document.querySelector("#btCalcular");
let h3ValorFinal = document.querySelector("#h3ValorFinal");

function valorCompra(){
    let camisetasPequenas = Number(camisetasP.value);
    let camisetasMedias = Number(camisetasM.value);
    let camisetasGrandes = Number(camisetasG.value);

    let valorP = 10;
    let valorM = 12;
    let valorG = 15;

    let calcularPedido = camisetasPequenas * valorP + camisetasMedias * valorM + camisetasGrandes * valorG;

    h3ValorFinal.textContent = "O valor total do pedido é de R$ " + calcularPedido + ".";

}

btCalcular.onclick = valorCompra;