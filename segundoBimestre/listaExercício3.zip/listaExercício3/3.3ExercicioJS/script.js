let qtdePaes = document.querySelector("#qtdePaes");
let qtdeBroa = document.querySelector("#qtdeBroa");
let btCalcular = document.querySelector("#btCalcular");
let h3ResultadoFinal = document.querySelector("#h3ResultadoFinal");
let h3ResultadoPoupanca = document.querySelector("#h3ResultadoPoupanca");

function calcularDados(){
    let paes = Number(qtdePaes.value);
    let broas = Number(qtdeBroa.value);

    let resultado = (paes * 0.12) + (broas * 1.50);

    let poupanca = resultado * (10 / 100);

    h3ResultadoFinal.innerHTML = 
       "O valor total de vendas no dia foi de R$ " + resultado.toFixed(2) + ".<br>" +
        "Sendo que R$ " + poupanca.toFixed(2) + " devem ser guardados na poupança (10%).";

}

btCalcular.onclick = function(){
    calcularDados();
}