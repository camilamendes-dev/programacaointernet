let nome = document.querySelector("#nome");
let dataNasc = document.querySelector("#dataNasc");
let btCalcular = document.querySelector("#btCalcular");
let h3DiasDeVida = document.querySelector("#h3DiasDeVida");

function calcularDias() {
    let nomePessoa = nome.value;
    let dataNascimento = new Date(dataNasc.value);
    // data atual em JavaScript, não precisa importar biblioteca. o objeto Date faz isso direto.
    let hoje = new Date();

    // getMonth() começa do zero (0 = janeiro, 11 = dezembro).
    // getDate() pega o dia do mês, não da semana.
    let idade = hoje.getFullYear() - dataNascimento.getFullYear();
    let mes = hoje.getMonth() - dataNascimento.getMonth();
    let dia = hoje.getDate() - dataNascimento.getDate();

    // Corrige se ainda não fez aniversário este ano
    if (mes < 0 || (mes === 0 && dia < 0)) {
        idade--;
    }

    let diasDeVida = idade * 365;

    h3DiasDeVida.textContent = nomePessoa + ", você já viveu o total de " + diasDeVida + " dias.";
}

btCalcular.onclick = calcularDias;