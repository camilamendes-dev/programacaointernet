let pesoPrato = document.querySelector("#pesoPrato");
let btCalcular = document.querySelector("#btCalcular");
let h3ValorFinal = document.querySelector("#h3ValorFinal");

function calcularValor(){
    let qtdeQuilo = Number(pesoPrato.value);
    let valorQuilo = 12;

    let resultado = qtdeQuilo * valorQuilo;

    // Formata para 2 casas decimais e usa vírgula no lugar do ponto
    let resultadoFormatado = resultado.toFixed(2).replace('.', ',');

    h3ValorFinal.textContent = "O valor a ser pago é de R$ " + resultadoFormatado + ".";
}

btCalcular.onclick = calcularValor;