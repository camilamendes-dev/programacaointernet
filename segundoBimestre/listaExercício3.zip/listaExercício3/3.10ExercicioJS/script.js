let diasTotais = document.querySelector("#diasTotais");
let btConverter = document.querySelector("#btConverter");
let h3Resultado = document.querySelector("#h3Resultado");

function converterTempo() {
    let totalDias = Number(diasTotais.value);


    // parseInt para remover decimal - sem arredondar.
    let anos = parseInt(totalDias / 360);
    let meses = parseInt((totalDias % 360) / 30);
    let dias = totalDias % 30;

    h3Resultado.textContent = "O tempo sem acidentes é de: " + anos + " ano(s), " + meses + " mês(es) e " + dias + " dia(s).";
}

btConverter.onclick = converterTempo;
