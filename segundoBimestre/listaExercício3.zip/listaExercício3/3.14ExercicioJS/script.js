let valorConta = document.querySelector("#valorConta");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function dividirConta() {
    let valor = Number(valorConta.value);

    let valorCarlos = parseInt(valor / 3);
    let valorAndre = parseInt(valor / 3);
    let valorFelipe = valor - (valorCarlos + valorAndre);

    h3Resultado.innerHTML = 
        "Carlos deve pagar: R$ " + valorCarlos.toFixed(2) + "<br>" +
        "André deve pagar: R$ " + valorAndre.toFixed(2) + "<br>" +
        "Felipe deve pagar: R$ " + valorFelipe.toFixed(2);
}

btCalcular.onclick = dividirConta;