let salarioAtual = document.querySelector("#salarioAtual");
let btCalcular = document.querySelector("#btCalcular");
let h3ResultadoAumento = document.querySelector("#h3ResultadoAumento");

function calcularAumento() {
    let salario = Number(salarioAtual.value);

    let salarioComAumento = salario + (salario * 0.15); 
    let desconto = salarioComAumento * 0.08; 
    let salarioFinal = salarioComAumento - desconto;

   h3ResultadoAumento.innerHTML = 
    "a) Salário atual: R$ " + salario.toFixed(2) + "<br>" +
    "b) Salário com aumento de 15%: R$ " + salarioComAumento.toFixed(2) + "<br>" +
    "c) Total de descontos (8%): R$ " + desconto.toFixed(2) + "<br>" +
    "d) Salário final com aumento: R$ " + salarioFinal.toFixed(2);
}

btCalcular.onclick = calcularAumento;
