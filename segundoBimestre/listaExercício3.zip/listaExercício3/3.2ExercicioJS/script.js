let qtdeCavalos = document.querySelector("#qtdeCavalos");
let btCalcular = document.querySelector("#btCalcular");
let resultadoFinal = document.querySelector("#resultadoFinal");

function calcularQtdeCavalos(){
    let cavalos = Number(qtdeCavalos.value);

    let resultado = cavalos * 4;

    resultadoFinal.textContent = "Serão necessárias " + resultado + " ferraduras para equipar todos os cavalos comprados.";
}

btCalcular.onclick = function(){
    calcularQtdeCavalos();
}