let x1 = document.querySelector("#x1");
let y1 = document.querySelector("#y1");
let x2 = document.querySelector("#x2");
let y2 = document.querySelector("#y2");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularDistancia() {
    let valorX1 = Number(x1.value);
    let valorY1 = Number(y1.value);
    let valorX2 = Number(x2.value);
    let valorY2 = Number(y2.value);

    let distancia = Math.sqrt(Math.pow(valorX2 - valorX1, 2) + Math.pow(valorY2 - valorY1, 2));

    h3Resultado.textContent = "A distância entre os pontos é: " + distancia.toFixed(2);
}

btCalcular.onclick = calcularDistancia;