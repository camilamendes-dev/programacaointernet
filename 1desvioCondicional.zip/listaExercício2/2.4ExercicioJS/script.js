let sabor1 = document.querySelector("#sabor1");
let sabor2 = document.querySelector("#sabor2");
let sabor3 = document.querySelector("#sabor3");
let sabor4 = document.querySelector("#sabor4");
let refrigerantes = document.querySelector("#refrigerantes");
let btCalcular = document.querySelector("#btCalcular");

let saboresEscolhidos = document.querySelector("#saboresEscolhidos");
let totalRefrigerantes = document.querySelector("#totalRefrigerantes");
let valorTotal = document.querySelector("#valorTotal");

btCalcular.onclick = function() {
    let s1 = sabor1.value;
    let s2 = sabor2.value;
    let s3 = sabor3.value;
    let s4 = sabor4.value;

    let quantidadeRefrigerantes = Number(refrigerantes.value);

    let precoPizza = 12;
    let precoRefri = 7;

    let total = (4 * precoPizza) + (quantidadeRefrigerantes * precoRefri);

    saboresEscolhidos.textContent = "Sabores escolhidos: " + s1 + ", " + s2 + ", " + s3 + ", " + s4;
    totalRefrigerantes.textContent = "Total de refrigerantes pedidos: " + quantidadeRefrigerantes;
    valorTotal.textContent = "Valor total a pagar: R$ " + total.toFixed(2);
};
