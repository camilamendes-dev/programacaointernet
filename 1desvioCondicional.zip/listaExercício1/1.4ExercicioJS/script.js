let inputPrimeiro = document.querySelector("#inputPrimeiro");
let inputSegundo = document.querySelector("#inputSegundo");
let inputTerceiro = document.querySelector("#inputTerceiro");
let btCalcularMedia = document.querySelector("#CalcularMedia");

let resultadoA = document.querySelector("#resultadoA");
let resultadoB = document.querySelector("#resultadoB");
let resultadoC = document.querySelector("#resultadoC");
let resultadoD = document.querySelector("#resultadoD");

function CalcularMedia() {
    let valor1 = Number(inputPrimeiro.value);
    let valor2 = Number(inputSegundo.value);
    let valor3 = Number(inputTerceiro.value);

    // a) Média Aritmética
    let mediaAritmetica = (valor1 + valor2 + valor3) / 3;

    // b) Média Ponderada (pesos 3, 2, 5)
    let mediaPonderada = (valor1 * 3 + valor2 * 2 + valor3 * 5) / (3 + 2 + 5);

    // c) Soma das duas médias
    let somaMedias = mediaAritmetica + mediaPonderada;

    // d) Média das médias
    let mediaDasMedias = somaMedias / 2;

    // Exibir os resultados
    resultadoA.textContent = `a) Média Aritmética: ${mediaAritmetica.toFixed(2)}`;
    resultadoB.textContent = `b) Média Ponderada: ${mediaPonderada.toFixed(2)}`;
    resultadoC.textContent = `c) Soma das Médias: ${somaMedias.toFixed(2)}`;
    resultadoD.textContent = `d) Média das Médias: ${mediaDasMedias.toFixed(2)}`;
}

btCalcularMedia.onclick = CalcularMedia;