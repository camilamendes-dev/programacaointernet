let h1Texto = document.querySelector("#h1Texto");
//querySelector esta importando os elementos do HTML, para ser possível manipular

let inputTexto = document.querySelector("#inputTexto");
let btTrocaTexto = document.querySelector("#btTrocaTexto");

function trocarTexto(){
    // retornando o texto digitado no campo da caixa na pagina
    let textoDigitado = inputTexto.value;
    
    // alterando o texto do elemento h1 com textContent
    h1Texto.textContent = textoDigitado;
   
}

btTrocaTexto.onclick = function(){
    trocarTexto();
}