let inputPrimeiro = document.querySelector("#inputPrimeiro");
let inputSegundo = document.querySelector("#inputSegundo");
let btSomar = document.querySelector("#btSomar");
let h1Resultado = document.querySelector("#h1Resultado");

function somar(){
    let numeroDigitado = Number(inputPrimeiro.value);
    let numeroDigitadoSegundo = Number(inputSegundo.value);

    h1Resultado.textContent = numeroDigitado + numeroDigitadoSegundo;
}

btSomar.onclick = function(){
    somar();
}
