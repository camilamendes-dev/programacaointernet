let inputPrimeiro = document.querySelector("#inputPrimeiro");
let btSomar = document.querySelector("#btSomar");
let h1Resultado = document.querySelector("#h1Resultado");

function Somar(){
    let numeroDigitado = Number(inputPrimeiro.value);

    h1Resultado.textContent = numeroDigitado+(numeroDigitado*(1/100));

}

btSomar.onclick = function(){
    Somar();
}
